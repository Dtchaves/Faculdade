#ifndef INSERTSORT_
#define INSERTSORT_

#include <stdlib.h>
#include <stdio.h>

/*H = 1*/
void Insertsort(int* Vetor, int Tamanho);


#endif