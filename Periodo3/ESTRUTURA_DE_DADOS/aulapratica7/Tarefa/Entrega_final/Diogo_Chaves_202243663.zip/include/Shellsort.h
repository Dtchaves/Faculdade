#ifndef SHELLSORT_
#define SHELLSORT_

#include <stdlib.h>
#include <stdio.h>

/*Hs pares*/
void Shellsort_H1(int* Vetor, int Tamanho);

/*H mais recomendado*/
void Shellsort_H2(int* Vetor, int Tamanho);


#endif