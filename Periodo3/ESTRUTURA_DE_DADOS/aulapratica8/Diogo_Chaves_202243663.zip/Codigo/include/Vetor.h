#ifndef VETOR
#define VETOR

#include <stdlib.h>
#include <stdio.h>


void Printar_Vetor(int* Vetor,int Tamanho);

void Copia_Vetor(int* Vetor_Copiar,int* Vetor_Copia,int Tamanho);


#endif