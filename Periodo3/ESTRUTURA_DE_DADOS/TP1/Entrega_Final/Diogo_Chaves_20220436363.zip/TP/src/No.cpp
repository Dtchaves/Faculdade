#include<iostream>
#include <../include/No.hpp>

using namespace std;

No::No(){
    Direita = NULL;
    Esquerda = NULL;
}